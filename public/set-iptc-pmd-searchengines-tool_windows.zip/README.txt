* Tool Package of set-iptc-pmd-searchengines

The files and directories in this Tool Package directory provide most of the resources required on your local computer.

The only missing resource is an installed ExifTool on MacOS or Linux computers. On Windows computers the included exiftool_windows.exe fulfills this requirement.

The full guidelines for using this Tool Package can be found on the How To page of a corresponding web site: 
- for information covering all operating systems go to https://set-iptc-pmd-searchengines.nitsvc.net/ui/howto
- for information focused on the Windows operating system go to https://set-iptc-pmd-searchengines.nitsvc.net/ui/howto/windows
- for information focused on the MacOS operating system go to https://set-iptc-pmd-searchengines.nitsvc.net/ui/howto/macos 
- for information focused on the Linux operating system go to https://set-iptc-pmd-searchengines.nitsvc.net/ui/howto/linux

Please read the How To page and follow the guidelines, step by step.


 