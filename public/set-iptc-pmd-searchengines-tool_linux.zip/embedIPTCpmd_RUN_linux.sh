#!/bin/bash

echo This script requires an installed ExifTool program - this is tested now

echo If ExifTool is installed the path to the executable is displayed.

which exiftool 2>/dev/null
if [ "$?" -ne "0" ]; then
  echo WARNING: Exiftool is NOT installed, the script cannot embed metadata into image files and terminates.
  read -p "Press [Enter] key to close"
  exit 1
fi

echo Great, ExifTool is installed on your computer, the script is executed now

# embedding IPTC Photo Metadata Standard properties in the file myiptcpmd.json
exiftool -v0 -r -overwrite_original -ext jpg -ext jpeg -ext tif -ext tiff -ext png -ext dng -ext psd -j=myiptcpmd.json ./images

echo DONE

read -p "Press [Enter] key to close"

