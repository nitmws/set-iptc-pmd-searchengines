﻿"""
Python script for embedding photo metadata into an image file
    which was dropped on the executable version of this script.

This script can be compiled to an Apple droplet executable or
    a Windows executable.

Dropping a folder on the app will process all image files in the folder
limited to filetypes: .jpg .jpeg .tif .tiff .psd .png .dng .tif

The results from Exiftool are recorded in a log file:  '*-RUNlog.txt' if DEBUG is True

Messages to the user are recorded in a log file: 'embedIPTCpmd_drop-log.txt'


Note on names of variables:
*_fp = file path
"""

import sys
import os
import datetime
import time
import subprocess
import shutil
from pathlib import PurePath

VERSION = '1.0.1 [2020-04-28]'

DEBUG = False  # control for RUNlog creation

DROPPEDITEMSMAX = 200  # Limits count of items on the command line = dropped items

ETJSONFNAME = 'myiptcpmd.json'  # name of the ExifTool metadata JSON file
COPYTARGETDIRNAME = 'dropped_images'  # name of the target directory for copying dropped files/directories


def write2runlog(logline):
    """
    Write to the debug log file if variable debug is set to true
    """
    if DEBUG:
        with open(os.path.join(currentdir, runlogfilename), mode='a') as runlogfile:
            dtnow = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            runlogfile.write('\n' + dtnow + ':  ' + logline)


def write2userlog(logline):
    """
    Write to the user log file
    """
    with open(os.path.join(currentdir, "embedIPTCpmd_drop-log.txt"), mode='a') as userlogfile:
        dtnow = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        userlogfile.write('\n' + dtnow + ':  ' + logline)


def get_dir_filesize(start_path='.'):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            # skip if it is symbolic link
            if not os.path.islink(fp):
                total_size += os.path.getsize(fp)
    return total_size


def cmd_list(cmd, opt="", image=""):
    """
    Build a command list for Exiftool
    by combining strings and building a list
    """
    # return a list for subprocess.run shell=False
    return [cmd] + [etparams_arg] + opt.split() + [image]


def f_type(ext):
    """
    Limit the Exiftool processing to specific file types
    This will add -ext to each file type specified
    Returns a string of unique -ext options
    """
    # return a string of -ext options for Exiftool
    opt = ' -ext '
    return opt + opt.join(set(ext.split()))


def runexiftool(file_or_dir_name):
    """
     Example command line: exiftool -v -r -overwrite_original -ext jpg jpeg {etc} -j=myiptcpmd.json images
    """
    cmd = shutil.which('exiftool')
    if subprocess._mswindows:
        if cmd is None:
            localet_fp = os.path.join(currentdir, 'exiftool_windows.exe')
            if os.path.isfile(localet_fp):
                cmd = localet_fp
    else:
        cmd = '/usr/local/bin/exiftool'
        if not os.path.exists(cmd):
            cmd = shutil.which('exiftool')

    if cmd is None:
        write2runlog("ExifTool is not found")
        write2userlog("ExifTool is not found on your computer - is it installed?")
        return

    # the option string
    etopts = ' '.join(['-r', '-overwrite_original', etfiles_arg])
    etargs = cmd_list(cmd, etopts, file_or_dir_name)  # the list of args

    print('.')  # to show to the Windows user processing activity
    etresult = subprocess.run(etargs, capture_output=True)
    write2runlog(' '.join(etresult.args))
    write2runlog(str(etresult.stdout))
    write2runlog(str(etresult.stderr) + '\n')

    userlogline = ''
    if etresult.returncode == 0:
        if os.path.isfile(file_or_dir_name):
            userlogline = 'File with just embedded PMD: ' + file_or_dir_name
        elif os.path.isdir(file_or_dir_name):
            userlogline = 'Directory/folder with just embedded PMD: ' + file_or_dir_name
    else:
        userlogline = 'Embedding PMD into this file or directory/folder did not work: ' + file_or_dir_name
    write2userlog(userlogline)


"""
MAIN part
"""
print('Processing started')  # displayed on Windows

# The current directory may be inside an .app package file,
currentdir = os.path.dirname(sys.argv[0])
if PurePath(sys.argv[0]).match('Contents/Resources/*.py'):  # This is an .app package
    currentdir = str(PurePath(currentdir).parents[2])

# check the count of dropped items, if too many: exit program.
if len(sys.argv) > DROPPEDITEMSMAX:
    write2userlog('Too many files and/or directories/folders were dropped on this program, the maximum is '
                  + str(DROPPEDITEMSMAX) + ' -- Processing stopped')
    print('\nToo many files / directories/folders dropped - maximum = ' + str(DROPPEDITEMSMAX)
          + ' -- Processing stopped')  # displayed on Windows
    time.sleep(5)
    sys.exit()

# check if the disk space required for copying dropped files exceeds the available free space of the drive
FILESIZEMAX = shutil.disk_usage(currentdir)[-1] - 3000000000  # free space on current drive minus about 3GB
# FILESIZEMAX = 1000000  ## for TESTING only

totalcopyfilesize = 0

for argitem in sys.argv[1:]:
    if os.path.isfile(argitem):
        totalcopyfilesize += os.path.getsize(argitem)
    elif os.path.isdir(argitem):
        for root, dirs, files in os.walk(argitem):
            totalcopyfilesize += sum(os.path.getsize(os.path.join(root, name)) for name in files)

if totalcopyfilesize > FILESIZEMAX:
    write2userlog('Dropped files require more space than available on your disk: '
                  + str(round(FILESIZEMAX / 1048576)) + ' MB. Exceeded by size of files: '
                  + str(round(totalcopyfilesize / 1048576)) + ' MB. -- Processing stopped')
    print('\nDropped files require more space than available on your disk -- Processing stopped')  # displayed on Windows
    time.sleep(5)
    sys.exit()

basename = os.path.basename(sys.argv[0])
runlogfilename = basename + '-RUNlog.txt'

write2runlog(currentdir)
write2runlog(' '.join(sys.argv))

if len(sys.argv) > 1:
    logline = ' Dropped file or directory/folder: '  # default setting
    errors = []
    etjson_fp = os.path.join(currentdir, ETJSONFNAME)
    if not os.path.isfile(etjson_fp):
        write2userlog('ExifTool Json file not found:  ' + etjson_fp)
        print('\nExifTool Json file not found -- Processing stopped')  # displayed on Windows
        time.sleep(5)
        sys.exit()

    copyto_fp = os.path.join(currentdir, COPYTARGETDIRNAME)
    # make the default copy destination directory
    os.makedirs(copyto_fp, exist_ok=True)

    # process each file or directory dropped on the program
    for dropped_fp in sys.argv[1:]:
        embedtarget_fp = copyto_fp  # default, if the copy action below does not work
        try:
            if os.path.isfile(dropped_fp):
                # copy a dropped single file to the dropped_images subdirectory
                sourcedfilename = os.path.basename(dropped_fp)
                embedtarget_fp = os.path.join(copyto_fp, sourcedfilename)
                # copy and preserve file system metadata
                shutil.copy2(dropped_fp, embedtarget_fp)
                logline = 'Dropped file: '
            elif os.path.isdir(dropped_fp):
                # copy a dropped directory to the dropped_images subdirectory
                # use only the lowest directory of the path for copying
                sourcedirname = os.path.split(dropped_fp)[-1]
                embedtarget_fp = os.path.join(copyto_fp, sourcedirname)
                # copy the directory
                shutil.copytree(dropped_fp, embedtarget_fp, dirs_exist_ok=True)
                logline = 'Dropped directory/folder: '
            else:
                write2userlog('File or directory not found' + dropped_fp)
                continue

        except OSError as why:
            # Error during the copy operation
            errors.extend((dropped_fp, embedtarget_fp, str(why)))

        if errors:
            logline = 'Copy file or directory/folder error: ' + dropped_fp
            write2userlog(logline)
            write2runlog(str(errors))
        else:
            logline += dropped_fp
            write2userlog(logline)

            etparams_arg = '-j=' + etjson_fp
            filetypes = ".jpg .jpeg .tif .tiff .psd .png .dng .tif"
            etfiles_arg = f_type(filetypes)
            runexiftool(embedtarget_fp)

else:
    write2userlog('No file specified, nothing processed - says embedIPTCpmd_drop version: ' + VERSION + ')')

print('\nProcessing done')
time.sleep(2)
