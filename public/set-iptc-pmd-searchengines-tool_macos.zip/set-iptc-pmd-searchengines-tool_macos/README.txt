* Tool Package of set-iptc-pmd-searchengines

The files and directories in this Tool Package directory provide most of the resources required on your local computer.

The only missing resource is an installed ExifTool on MacOS or Linux computers. On Windows computers the included exiftool_windows.exe fulfills this requirement.

The full guidelines for using this Tool Package can be found on the How To page of a corresponding web site: go to https://set-iptc-pmd-searchengines.nitsvc.net/ui/howto

Please read the guidelines and follow them, step by step.


 